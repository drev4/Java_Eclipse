package material;
/*
 * Diego Revuelta Hoz
 */
import java.util.Comparator;

public class EnterosComparador implements Comparator<Integer>{


	@Override
	public int compare(Integer o1, Integer o2) {
		
		return o1.compareTo(o2);
		
	}

}
